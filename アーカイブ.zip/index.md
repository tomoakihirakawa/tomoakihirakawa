<img src="profile.png" alt="profile" width="200"/>

<h2>研究内容</h2>

水面波-物体相互作用を計算するための数値解析手法の開発を主に行なっています．
現在は，境界要素法による計算の発展に特に力を入れています：

<ul>
  <li>数値的安定化（Arbitrary Lagrangian Eulerianの活用）</li>
  <li>高速化（高速多重極展開の活用）</li>
  <li>浮体係留策のモデリング</li>
</ul>

また，以下のような内容にも興味を持っており，学生の研究テーマとして扱っています．
<ul>
    <li>粒子法の一種であるSPH法（Smoothed Particle Hydrodynamics）の開発
</li>
    <li>魚の遊泳法（生物流体力学と魚型ロボットを活用）</li>
</ul>

<img src="BEM.png" alt="BEM" width="300"/>
<img src="SPH.png" alt="SPH" width="300"/>
<img src="fish.png" alt="fish" width="300"/>